package com.example.banplugin;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class BanPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        getLogger().info("BanPlugin has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("BanPlugin has been disabled!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("ban")) {
            if (args.length < 1) {
                sender.sendMessage("Usage: /ban <player>");
                return false;
            }

            Player target = Bukkit.getPlayer(args[0]);

            if (target == null) {
                sender.sendMessage("Player not found!");
                return true;
            }

            target.kickPlayer("You have been banned from this server!");
            Bukkit.getBanList(org.bukkit.BanList.Type.NAME).addBan(target.getName(), "Banned by admin", null, sender.getName());
            Bukkit.broadcastMessage(target.getName() + " has been banned by " + sender.getName());
            return true;
        }

        return false;
    }
}
